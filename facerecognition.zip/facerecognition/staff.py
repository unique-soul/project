from flask import Blueprint,render_template,request,redirect,url_for,session
from database import *
import uuid
from core import *
staff=Blueprint('staff',__name__)

@staff.route('/staffhome')
def staffhome():
	return render_template('staffhome.html')
@staff.route('/staffviewwork')
def staffviewwork():
	data={}
	q="select * from works inner join staff using(staff_id)"
	res=select(q)
	data['workdetails']=res
		
	return render_template('staffviewwork.html',data=data)
@staff.route('/workuploads',methods=['get','post'])
def workuploads():
	data={}
	id=request.args['pid']
	if 'submits' in request.form:
		image=request.files['image']
		path="static/uploads/"+str(uuid.uuid4())+image.filename
		image.save(path)
		q="insert into workuploads valuess(null,'%s','%s',curdate())" %(id,path)
		insert(q)
		return redirect(url_for('staff.staffviewwork'))
	q="select * from workuploads "
	res=select(q)
	data['workuploaddetails']=res
		
	return render_template('workupload.html',data=data)
@staff.route('/staffsendfeedback',methods=['get','post'])
def staffsendfeedback():
	data={}

	if 'send' in request.form:
		description=request.form['description']
		q="insert into feedback values(null,'%s','%s','pending',curdate())" %(session['uid'],description)
		insert(q)
		return redirect(url_for('staff.staffsendfeedback'))
	q="select * from feedback"
	res=select(q)
	data['feedback']=res
		
	return render_template('staffsendfeedback.html',data=data)
@staff.route('/staffregisterstudent',methods=['get','post'])
def staffregisterstudent():
	data={}
	if 'submits' in request.form:
		fname=request.form['first_name']
		lname=request.form['last_name']
		clss=request.form['class']
		dob=request.form['dob']
		
		q="insert into login values(null,'%s','%s','student')"
		id=insert(q)

		q="insert into student value('%s','%s','%s','%s','%s')" %(id,fname,lname,clss,dob)
		insert(q)
		path=""
		# Check whether the   
		# specified path is   
		# an existing file 
		pid=str(id)
		isFile = os.path.isdir("static/trainimages/"+pid)  
		print(isFile)
		if(isFile==False):
			os.mkdir('static\\trainimages\\'+pid)
		image1=request.files['image1']
		path="static/trainimages/"+pid+"/"+str(uuid.uuid4())+image1.filename
		image1.save(path)

		image2=request.files['image2']
		path="static/trainimages/"+pid+"/"+str(uuid.uuid4())+image2.filename
		image2.save(path)

		image3=request.files['image3']
		path="static/trainimages/"+pid+"/"+str(uuid.uuid4())+image3.filename
		image3.save(path)
		enf("static/trainimages/")
		
		flash('Added successfully...')
		return redirect(url_for('staff.staffregisterstudent'))
	q="select * from student"
	res=select(q)
	data['studentdetails']=res
		
	return render_template('staffregisterstudent.html',data=data)
@staff.route('/staffviewstudentattendance',methods=['get','post'])
def staffviewstudentattendance():
	data={}
	if "submits" in request.form:
		sd=request.form['selectdate']+"%"
		q="select * from student inner join attendance on attendance.attended_id=student.student_id where type='student' and date like '%s' " %(sd)
	else:
		q="select * from student inner join attendance on attendance.attended_id=student.student_id where type='student'"
	res=select(q)
	data['studentdetails']=res
		
	return render_template('staffviewstudentattendance.html',data=data)



