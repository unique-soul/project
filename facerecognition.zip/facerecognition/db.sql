/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.7.9 : Database - facerecognition
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`facerecognition` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `facerecognition`;

/*Table structure for table `attendance` */

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `attendance_id` int(100) NOT NULL AUTO_INCREMENT,
  `attended_id` int(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `time` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`attendance_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `attendance` */

insert  into `attendance`(`attendance_id`,`attended_id`,`date`,`time`,`type`) values (5,16,'2021-03-22','13:23:26','student'),(4,15,'2021-03-22','13:14:08','staff'),(6,15,'2021-03-26','15:44:21','staff'),(7,15,'2021-03-29','21:22:44','staff'),(8,33,'2021-03-29','23:36:40','student'),(9,34,'2021-03-30','10:00:16','staff'),(10,37,'2021-03-30','10:35:10','student');

/*Table structure for table `college` */

DROP TABLE IF EXISTS `college`;

CREATE TABLE `college` (
  `college_id` int(100) NOT NULL AUTO_INCREMENT,
  `college_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`college_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `college` */

/*Table structure for table `feedback` */

DROP TABLE IF EXISTS `feedback`;

CREATE TABLE `feedback` (
  `feedback_id` int(100) NOT NULL AUTO_INCREMENT,
  `staff_id` int(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `reply` varchar(100) DEFAULT NULL,
  `date_time` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `feedback` */

insert  into `feedback`(`feedback_id`,`staff_id`,`description`,`reply`,`date_time`) values (1,3,'sdvfbgh','gghg','2021-03-10'),(2,15,'sdfghj,','hii','2021-03-29'),(3,15,'heyy','pending','2021-03-29'),(4,34,'nice work','pending','2021-03-30');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `login_id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `user_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`login_id`,`username`,`password`,`user_type`) values (2,'admin','admin','admin'),(37,'%s','%s','student'),(36,'%s','%s','student'),(35,'%s','%s','student'),(34,'misna','1234','staff'),(33,'%s','%s','student'),(32,'athira','1234','staff');

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `staff_id` int(100) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `age` int(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `staff` */

insert  into `staff`(`staff_id`,`first_name`,`last_name`,`qualification`,`age`,`gender`,`phone`,`email`) values (32,'athira','bose','bca',20,'female','9422255513','athira@gmail.com'),(34,'misna','ca','professor',25,'female','7896541235','misna@gmail.com');

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `student_id` int(100) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `class` varchar(100) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`student_id`,`first_name`,`last_name`,`class`,`dob`) values (36,'athira','bose','bca','2021-03-08'),(35,'merin','maria','bca','2021-03-03'),(27,'vichu','n','6','2021-03-02'),(33,'usha','bose','bcom','2020-06-10'),(37,'mary','francis','bca','2021-03-18');

/*Table structure for table `works` */

DROP TABLE IF EXISTS `works`;

CREATE TABLE `works` (
  `work_id` int(100) NOT NULL AUTO_INCREMENT,
  `staff_id` int(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `created_date` varchar(100) DEFAULT NULL,
  `last_date` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`work_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `works` */

insert  into `works`(`work_id`,`staff_id`,`title`,`description`,`created_date`,`last_date`,`status`) values (1,1,'designing','add design','12/11/2020','20/01/2021','pending'),(3,2,'developer','create web','13/06/2020','25/09/2023','pending');

/*Table structure for table `workuploads` */

DROP TABLE IF EXISTS `workuploads`;

CREATE TABLE `workuploads` (
  `uploads_id` int(100) NOT NULL AUTO_INCREMENT,
  `work_id` int(11) DEFAULT NULL,
  `file_path` varchar(100) DEFAULT NULL,
  `date_time` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`uploads_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `workuploads` */

insert  into `workuploads`(`uploads_id`,`work_id`,`file_path`,`date_time`) values (1,3,'static/uploads/f1001bd9-7748-4131-91e1-bfe44dd3953d2.2.PNG','2021-02-27'),(2,1,'static/uploads/faf63699-6407-4f6d-b33e-242f28f9fd472.4.PNG','2021-02-27');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
