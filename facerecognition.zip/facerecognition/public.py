from flask import Blueprint,render_template,request,redirect,url_for,session
from database import *

public=Blueprint('public',__name__)

@public.route('/')
def home():
	return render_template('home.html')

@public.route('/login',methods=['get','post'])
def login():
	if 'submits' in request.form:
		user=request.form['username']
		passs=request.form['password']
		q="select *from login where username='%s' and password='%s'" %(user,passs)
		res=select(q)
		if res:
			session['uid']=res[0]['login_id']
			if res[0]['user_type']=="admin":
				return redirect(url_for('admin.adminhome'))
			if res[0]['user_type']=="staff":
				
				return redirect(url_for('staff.staffhome'))

				
	return render_template('login.html')

