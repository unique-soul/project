from flask import Blueprint,render_template,request,redirect,url_for
from database import *
import uuid
from core import *
admin=Blueprint('admin',__name__)

@admin.route('/adminhome')
def adminhome():
	return render_template('adminhome.html')
@admin.route('/registration',methods=['get','post'])
def registration():
	data={}

	if 'action' in request.args:
		action=request.args['action']
		id=request.args['sid']
	else:
		action=None

	if action=="update":
		q="select * from staff where staff_id='%s'" %(id)
		res=select(q)
		data['updatess']=res

	if action=="delete":
		q="delete from staff where staff_id='%s'" %(id)
		res=delete(q)
		return redirect(url_for('admin.registration'))



	if 'update' in request.form:

		fname=request.form['first_name']
		lname=request.form['last_name']
		qual=request.form['qualification']
		age=request.form['age']
		gender=request.form['gender']
		phn=request.form['phone']
		email=request.form['email']

		q="update staff set first_name='%s',last_name='%s',qualification='%s',age='%s',gender='%s',phone='%s',email='%s' where staff_id='%s'" %(fname,lname,qual,age,gender,phn,email,id)
		update(q)
		return redirect(url_for('admin.registration'))

	if 'submits' in request.form:
		fname=request.form['first_name']
		lname=request.form['last_name']
		qual=request.form['qualification']
		age=request.form['age']
		gender=request.form['gender']
		phn=request.form['phone']
		email=request.form['email']
		username=request.form['username']
		password=request.form['password']
		# image1=request.files['image1']
		# path1="static/uploads/"+str(uuid.uuid4())+image1.filename
		# image1.save(path1)
		# image2=request.files['image2']
		# path2="static/uploads/"+str(uuid.uuid4())+image2.filename
		# image2.save(path2)
		# image3=request.files['image3']
		# path3="static/uploads/"+str(uuid.uuid4())+image3.filename
		# image3.save(path3)
		q="insert into login values(null,'%s','%s','staff')" %(username,password)
		id=insert(q)
		q="insert into staff value('%s','%s','%s','%s','%s','%s','%s','%s')" %(id,fname,lname,qual,age,gender,phn,email)
		insert(q)

		# path = 'static/uploads/'
		path=""
		# Check whether the   
		# specified path is   
		# an existing file 
		pid=str(id)
		isFile = os.path.isdir("static/trainimages/"+pid)  
		print(isFile)
		if(isFile==False):
			os.mkdir('static\\trainimages\\'+pid)
		image1=request.files['image1']
		path="static/trainimages/"+pid+"/"+str(uuid.uuid4())+image1.filename
		image1.save(path)

		image2=request.files['image2']
		path="static/trainimages/"+pid+"/"+str(uuid.uuid4())+image2.filename
		image2.save(path)

		image3=request.files['image3']
		path="static/trainimages/"+pid+"/"+str(uuid.uuid4())+image3.filename
		image3.save(path)
		enf("static/trainimages/")
		
		flash('Added successfully...')
		return redirect(url_for('admin.registration'))
	q="select * from staff"
	res=select(q)
	data['staffdetails']=res
		
	return render_template('registration.html',data=data)
@admin.route('/adminviewstaffattendance',methods=['get','post'])
def adminviewstaffattendance():
	data={}
	if "submits" in request.form:
		sd=request.form['selectdate']+"%"
		q="select * from staff inner join attendance on attendance.attended_id=staff.staff_id where type='staff' and date like '%s' " %(sd)
	else:
		q="select * from staff inner join attendance on attendance.attended_id=staff.staff_id where type='staff'"
	res=select(q)
	data['staffdetails']=res
		
	return render_template('adminviewstaffattendance.html',data=data)
@admin.route('/adminviewstudentattendance',methods=['get','post'])
def adminviewstudentattendance():
	data={}
	if "submits" in request.form:
		sd=request.form['selectdate']+"%"
		q="select * from student inner join attendance on attendance.attended_id=student.student_id where type='student' and date like '%s' " %(sd)
	else:
		q="select * from student inner join attendance on attendance.attended_id=student.student_id where type='student'"
	print(q)
	res=select(q)

	data['studentdetails']=res
		
	return render_template('adminviewstudentattendance.html',data=data)
@admin.route('/adminuploadworks',methods=['get','post'])
def adminuploadworks():
	data={}
	if 'action' in request.args:
		action=request.args['action']
		id=request.args['pid']
	else:
		action=None
	if action=="delete":
		q="delete from works where work_id='%s'" %(id)
		delete(q)
		return redirect(url_for('admin.adminuploadworks'))
	if action=="update":
		q="select * from works where work_id='%s'" %(id)
		res1=select(q)
		data['updatess']=res1
	if 'submits' in request.form:
		title=request.form['title']
		description=request.form['description']
		created_date=request.form['created_date']
		last_date=request.form['last_date']
		q="update works set title='%s',description='%s',created_date='%s',last_date='%s' where work_id='%s'" %(title,description,created_date,last_date,id)
		update(q)
		return redirect(url_for('admin.adminuploadworks'))

	if 'submits' in request.form:
		staff_id=request.form['staff_id']
		title=request.form['title']
		description=request.form['description']
		created_date=request.form['created_date']
		last_date=request.form['last_date']
		q="insert into works values(null,'%s','%s','%s','%s','%s','pending')" %(staff_id,title,description,created_date,last_date)
		insert(q)
	q="select * from works inner join staff using(staff_id)"
	res=select(q)
	data['workdetails']=res
	q1="select * from staff"
	res1=select(q1)
	data['staffdetails']=res1

		
	return render_template('adminuploadworks.html',data=data)
@admin.route('/adminviewfeedback',methods=['get','post'])
def adminviewfeedback():
	data={}
	q="select * from staff inner join feedback using(staff_id)"
	res=select(q)
	data['feedback']=res

	i=1
	for row in res:
		if 'replys'+str(i) in request.form:
			reply=request.form['reply'+str(i)]
			id=request.form['ids'+str(i)]
			q="UPDATE feedback SET reply='%s',date_time=CURDATE() WHERE staff_id='%s'"%(reply,id)
			update(q)
			return redirect(url_for("admin.adminviewfeedback"))
		i=i+1

		
	return render_template('adminviewfeedback.html',data=data)
@admin.route('/adminviewstudent',methods=['get','post'])
def adminviewstudent():
	data={}
	q="select * from student "
	res=select(q)
	data['studentdetails']=res
		
	return render_template('adminviewstudent.html',data=data)

@admin.route('/markattanadance')
def markattanadance():
	s=val()
	return render_template('markattandance.html')




